Backup Neo4j - Sistema Terminal
================================
Data: 2025-08-24 01:45
Nós: 6
Relacionamentos: 3

Como restaurar:
1. Extrair: unzip BACKUP_ATUAL_20250824_014514.zip
2. Executar: docker exec -i terminal-neo4j cypher-shell -u neo4j -p password < backup_atual_2025-08-24_01-43-18.cypher

Conteúdo:
- Memory: Configuração MCP
- ProjectRules: Container de regras
- Rule (3x): Regras do sistema
- Learning: Aprendizado sobre backup
