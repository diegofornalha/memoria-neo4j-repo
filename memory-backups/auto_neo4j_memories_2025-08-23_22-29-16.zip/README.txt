Neo4j Memory Backup
===================
Data: 2025-08-23 22-29-16
Tipo: auto

Estatísticas:
- Nós: 
- Relacionamentos: 

Como restaurar:
1. Extrair: unzip auto_neo4j_memories_2025-08-23_22-29-16.zip
2. Usar o script: ./restore-memory.sh
